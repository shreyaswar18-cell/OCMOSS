# OCMOSS

**Observe • Control • Monitor Operating System**

OCMOSS is a Windows Operating System Monitoring SDK written in Python. It provides developers with simple APIs to retrieve operating system events, process information, and network information in a structured way.
OCMOSS is designed to expose operating system information that is often hidden or difficult for users to access. The goal is to provide developers with a simple, modular Python SDK for monitoring Windows system events, processes, and network activity through a clean and consistent API.

---

# Features

## Version 1.0 – Operating System Lifecycle

- System Started
- Last Shutdown
- Current Uptime
- Last Restart
- Sleep Started
- Wake Up
- Power Source Changed

---

## Version 2.0 – Process Monitoring

- Running Applications
- Process Count
- Process Memory Usage

---

## Version 3.0 – Network Monitoring

- Network Information
- Internet Status
- IP Address
- Wi-Fi Information
- Wi-Fi Passwords

---

# Supported Platform

- Windows 10
- Windows 11

Python Version:

- Python 3.11+
- Python 3.12+
- Python 3.13+

---

# Installation

```bash
pip install ocmoss
```

---

# Quick Start

```python
import ocmoss
```

---

# Project Structure

```
OCMOSS
│
├── ocmoss
│   ├── events
│   ├── windows
│   └── core
│
├── main.py
├── pyproject.toml
├── README.md
└── LICENSE
```

---

# Current Modules

### Operating System Lifecycle

- SystemStarted
- LastShutdown
- CurrentUptime
- LastRestart
- SleepStarted
- WakeUp
- PowerSourceChanged

### Process Monitoring

- RunningApplications
- ProcessCount
- ProcessMemoryUsage

### Network Monitoring

- NetworkInformation
- InternetStatus
- IPAddress
- WiFiInformation
- WiFiPasswords

---

# Roadmap

## Version 4.0 – Privacy Monitoring

- WebcamStatus
- MicrophoneStatus

Future versions will expand OCMOSS with additional monitoring capabilities.

---

# License

Copyright 2026 Shreyas Chimalwar

Licensed under the Apache License, Version 2.0.

---

# Author

Shreyas Chimalwar

GitHub: *(Add your GitHub profile here after publishing.)*